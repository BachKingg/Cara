var express = require('express');
var router = express.Router();
var loaitinModels = require('../models/loaitinModels')
    /* GET users listing. */
router.get('/', function(req, res, next) {
    loaitinModels.read((data) => {
        res.render('admin/loaitin', { data })
    })
});

// ADD
router.get('/addloaitin', function(req, res, next) {
    res.render('admin/add-loaitin', )
});


router.post('/addloaitin', function(req, res, next) {
    console.log(req.body);
    loaitinModels.insert(req.body, (data) => {
        console.log(data);
    })
    res.redirect('/admin')
});

// UPDATE
router.get('/update/:id', function(req, res, next) {
    var id = req.params.id;
    loaitinModels.selectOne(id, (data) => {
        console.log(data);
        res.render('admin/update-loaitin', { data })
    })
});

router.post('/updateloaitin', function(req, res, next) {
    let data = {
        id: req.body.id,
        tenLoai: req.body.name,
        thuTu: req.body.thutu,
        anHien: req.body.anHien
    }
    loaitinModels.update(data, (data) => {
        res.redirect('/admin')
    })
});

// DELETE

router.get('/delete/:id', function(req, res, next) {
    let id = req.params.id;
    loaitinModels.delete(id, (data) => {
        res.redirect('/admin');
    })
});


// TIN
router.get('/tin', function(req, res, next) {
    loaitinModels.readTin((data) => {
        console.log(data);
        res.render('admin/tin', { data })
    })
});

// ADD
router.get('/addtin', function(req, res, next) {
    loaitinModels.readLoaitin((data) => {
        res.render('admin/add-tin', { loaitin: data })
    })
});


router.post('/addtin', function(req, res, next) {
    console.log(req.body);
    loaitinModels.insertTin(req.body, (data) => {
        console.log(data);
    })
    res.redirect('/admin/tin')
});

router.get('/updatetin/:id', function(req, res, next) {
    var id = req.params.id;
    loaitinModels.selectOneTin(id, (data) => {
        loaitinModels.readLoaitin((loaitin) => {
            res.render('admin/update-tin', { data: data, loaitin: loaitin })
        })
    })
});

router.post('/updatetin', function(req, res, next) {
    let data = {
        id: req.body.id,
        idLoaiTin: req.body.idLoaiTin,
        tenLoai: req.body.name,
        thuTu: req.body.thutu,
        anHien: req.body.anHien
    }
    loaitinModels.updateTin(data, (data) => {
        res.redirect('/admin/tin')
    })
});
router.get('/deletetin/:id', function(req, res, next) {
    let id = req.params.id;
    loaitinModels.deleteTin(id, (data) => {
        res.redirect('/admin/tin');
    })
});

module.exports = router;