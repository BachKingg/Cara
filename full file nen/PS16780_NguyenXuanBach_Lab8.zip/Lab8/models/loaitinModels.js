const mongo = require('mongodb');
const mc = mongo.MongoClient;
const url = "mongodb://localhost:27017/";


exports.insert = (loai, callback) => {
    mc.connect(url, (err, db) => {
        if (err) throw err;
        let database = db.db('Labmongo')
        var myquery = { "tenLoai": loai.name, "thuTu": loai.thutu, "anHien": loai.anHien };
        database.collection("loaitin").insertOne(myquery, function(err, res) {
            callback(res)
            db.close();
        });
    })
}

exports.read = (callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        database.collection('loaitin').find({}).toArray((err, res) => {
            callback(res)
            db.close()
        })
    })
}
exports.readLoaitin = (callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        database.collection('loaitin').find({}).toArray((err, res) => {
            callback(res)
            db.close()
        })
    })
}
exports.selectOne = (id, callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        database.collection("loaitin").findOne({ _id: mongo.ObjectId(id) }, function(err, res) {
            callback(res)
            db.close();
        });
    })
}
exports.delete = (id, callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        database.collection('loaitin').deleteOne({ _id: mongo.ObjectId(id) }, (err, data) => {
            if (err) throw err;
            callback(data)
            db.close()
        })
    })
}

exports.update = (data, callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        let updatedata = {
            $set: {
                tenLoai: data.tenLoai,
                thuTu: data.thuTu,
                anHien: data.anHien
            }
        }
        database.collection('loaitin').updateOne({ _id: mongo.ObjectId(data.id) }, updatedata, (err, data) => {
            if (err) throw err;
            callback(data)
            db.close()
        })
    })
}

exports.addtin = (data, callback) => {
    console.log(data);
    mc.connect(url, (err, db) => {
        if (err) throw err;
        let database = db.db('Labmongo')
        var myquery = { "tenloai": data.tenloai, "noidung": data.nodung, "idloai": data.loai, "anhien": true };
        database.collection("tintuc").insertOne(myquery, function(err, res) {
            callback(res)
            db.close();
        });
    })
}

exports.insertTin = (loai, callback) => {
    mc.connect(url, (err, db) => {
        if (err) throw err;
        let database = db.db('Labmongo')
        var myquery = { "idLoai": loai.idLoaitin, "tenLoai": loai.name, "thuTu": loai.thutu, "anHien": loai.anHien };
        database.collection("tintuc").insertOne(myquery, function(err, res) {
            callback(res)
            db.close();
        });
    })
}
exports.readTin = (callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        database.collection('tintuc').find({}).toArray((err, res) => {
            callback(res)
            db.close()
        })
    })
}
exports.selectOneTin = (id, callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        database.collection("tintuc").findOne({ _id: mongo.ObjectId(id) }, function(err, res) {
            callback(res)
            db.close();
        });
    })
}
exports.updateTin = (data, callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        let updatedata = {
            $set: {
                idLoai: data.idLoaiTin,
                tenLoai: data.tenLoai,
                thuTu: data.thuTu,
                anHien: data.anHien
            }
        }
        database.collection('tintuc').updateOne({ _id: mongo.ObjectId(data.id) }, updatedata, (err, data) => {
            if (err) throw err;
            callback(data)
            db.close()
        })
    })
}
exports.deleteTin = (id, callback) => {
    mc.connect(url, (err, db) => {
        let database = db.db('Labmongo');
        database.collection('tintuc').deleteOne({ _id: mongo.ObjectId(id) }, (err, data) => {
            if (err) throw err;
            callback(data)
            db.close()
        })
    })
}